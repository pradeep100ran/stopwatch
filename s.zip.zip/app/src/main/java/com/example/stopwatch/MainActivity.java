package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int seconds = 0;
    private boolean running = false;
    private Handler handler = new Handler();

    private TextView timerText;
    private Button startButton, stopButton, resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerText = findViewById(R.id.timerText);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        startButton.setOnClickListener(v -> running = true);
        stopButton.setOnClickListener(v -> running = false);
        resetButton.setOnClickListener(v -> {
            running = false;
            seconds = 0;
            updateTimerText();
        });

        runTimer();
    }

    private void runTimer() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                updateTimerText();
                if (running) seconds++;
                handler.postDelayed(this, 1000);
            }
        });
    }

    private void updateTimerText() {
        int hrs = seconds / 3600;
        int mins = (seconds % 3600) / 60;
        int secs = seconds % 60;
        timerText.setText(String.format("%02d:%02d:%02d", hrs, mins, secs));
    }
}